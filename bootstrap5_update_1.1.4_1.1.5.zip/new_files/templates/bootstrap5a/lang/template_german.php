<?php
define('BUTTON_EPAYPAL_DE_TEXT', '<span class="paypal0 small"><strong>DIREKT ZU&nbsp;&nbsp;</strong></span><span class="paypal1">PAY</span><span class="paypal2">PAL</span>');
define('BUTTON_SMALL_CONTINUE_TEXT', 'Ausw&auml;hlen');
defined('BS5_MORECATS_SHOW') or define('BS5_MORECATS_SHOW', 'mehr anzeigen ...');
defined('BS5_MORECATS_HIDE') or define('BS5_MORECATS_HIDE', 'weniger anzeigen ...');
