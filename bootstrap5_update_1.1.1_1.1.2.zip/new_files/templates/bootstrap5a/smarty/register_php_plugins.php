<?php
/* -----------------------------------------------------------------------------------------
   $Id: register_php_plugins.php 15292 2023-07-06 12:08:14Z GTB $

   modified eCommerce Shopsoftware
   http://www.modified-shop.org

   Copyright (c) 2009 - 2013 [www.modified-shop.org]
   -----------------------------------------------------------------------------------------
   Released under the GNU General Public License
   ---------------------------------------------------------------------------------------*/

  $register_php_plugins = array(
    'defined',
    'sizeof',
    'strpos',
    'substr',
    'strlen',
    'count',
    'intval',
    'nl2br',
    'sprintf',
    'strtotime',
    'number_format',
    'stripslashes',
    'array_reverse',
    'xtc_href_link',
    'htmlentities',
    'xtc_date_short',
  );
