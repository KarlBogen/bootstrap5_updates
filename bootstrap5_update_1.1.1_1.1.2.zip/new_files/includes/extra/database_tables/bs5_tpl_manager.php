<?php
/* ------------------------------------------------------------
	Module "Bootstrap 5 Template-Manager" made by Karl

	modified eCommerce Shopsoftware
	http://www.modified-shop.org

	Released under the GNU General Public License
-------------------------------------------------------------- */

define('TABLE_BS5_TPL_MANAGER_CONFIG', 'bs5_tpl_manager_config');
define('TABLE_BS5_TPL_MANAGER_THEME', 'bs5_tpl_manager_theme');
/* ------------------------------------------------------------
	Module "Kundenerinnerung Modified Shop 3.0.2 mit Opt-in" made by Karl

	Based on: Kundenerinnerung_Multilingual_advanced_modified-shop-1.06
	Based on: xt-module.de customers remind
	erste Anpassung von: Fishnet Services - Gemsjäger 30.03.2012
	Zusatzfunktionen eingefügt sowie Fehler beseitigt von Ralph_84
	Aufgearbeitet für die Modified 1.06 rev4356 von Ralph_84

	modified eCommerce Shopsoftware
	http://www.modified-shop.org

	Released under the GNU General Public License
-------------------------------------------------------------- */

define('TABLE_BS5_CUSTOMERS_REMIND', 'bs5_customers_remind');
define('TABLE_BS5_CUSTOMERS_REMIND_RECIPIENTS', 'bs5_customers_remind_recipients');
define('TABLE_BS5_CUSTOMERS_REMIND_RECIPIENTS_HISTORY', 'bs5_customers_remind_recipients_history');
defined('TABLE_BS5_SIMULATED_CRON_RECORDS') or define('TABLE_BS5_SIMULATED_CRON_RECORDS', 'bs5_simulated_cron_records');
?>