<?php
/* ------------------------------------------------------------
	Module "Bootstrap 5 Template-Manager" made by Karl

	modified eCommerce Shopsoftware
	http://www.modified-shop.org

	Released under the GNU General Public License
-------------------------------------------------------------- */

// Zusatzmodul Kundenerinnerung
define('FILENAME_BS5_CUSTOMERS_REMIND','bs5_customers_remind.php');
// Zusatzmodul Billiger gesehen
define('BS5_FILENAME_CHEAPLY_SEE', 'bs5_cheaply_see.php');
// Zusatzmodul Frage zum Produkt
define('BS5_FILENAME_PRODUCT_INQUIRY', 'bs5_product_inquiry.php');
// Zusatzmodul Rezensionsaufgliederung nach vergebenen Sternen (Awids Rating Breakdown)
define('BS5_FILENAME_POPUP_REVIEWS', 'bs5-popup_reviews.php');
?>