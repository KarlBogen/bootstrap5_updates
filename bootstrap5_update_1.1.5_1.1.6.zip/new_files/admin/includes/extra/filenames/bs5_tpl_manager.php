<?php
/* ------------------------------------------------------------
	Module "Bootstrap 5 Template-Manager" made by Karl

	modified eCommerce Shopsoftware
	http://www.modified-shop.org

	Released under the GNU General Public License
-------------------------------------------------------------- */

define('FILENAME_BS5_TPL_MANAGER_CONFIG', 'bs5_tpl_manager_config.php');
define('FILENAME_BS5_TPL_MANAGER_THEME','bs5_tpl_manager_theme.php');
define('FILENAME_BS5_TPL_MANAGER_THEME_PREVIEW','bs5_tpl_manager_theme_preview.php');
// Zusatzmodul Kundenerinnerung bei ausverkauftem Artikel
define('FILENAME_BS5_CUSTOMERS_REMIND','bs5_customers_remind.php');
define('FILENAME_BS5_CUSTOMERS_REMIND_RECIPIENTS','bs5_customers_remind_recipients.php');
define('FILENAME_BS5_BANNER_MANAGER','bs5_banner_manager.php');
